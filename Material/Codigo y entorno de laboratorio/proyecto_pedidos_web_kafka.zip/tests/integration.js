import test from "node:test";
import assert from "node:assert/strict";
import { setTimeout } from "node:timers/promises";
import { Kafka, logLevel } from "kafkajs";

const ordersUrl = process.env.ORDERS_URL || "http://localhost:3001";
const billingUrl = process.env.BILLING_URL || "http://localhost:3002";

async function eventually(check) {
  const deadline = Date.now() + 45000;
  while (Date.now() < deadline) {
    const result = await check();
    if (result) return result;
    await setTimeout(300);
  }
  assert.fail("Timed out waiting for asynchronous event processing");
}

async function consumedCount() {
  const metrics = await (await fetch(`${billingUrl}/metrics`)).text();
  const counter = metrics
    .split("\n")
    .find(
      (line) =>
        line.startsWith("events_consumed_total{") &&
        line.includes('topic="orders.created"'),
    );
  return counter ? Number(counter.split(" ").at(-1)) : 0;
}

test(
  "real Kafka: order becomes invoiced, and duplicate events do not duplicate invoices",
  { timeout: 90000 },
  async () => {
    const invalid = await fetch(`${ordersUrl}/api/orders`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ customer: "Test", items: [] }),
    });
    assert.equal(invalid.status, 400);
    const response = await fetch(`${ordersUrl}/api/orders`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customer: "Prueba de integracion",
        items: [{ productId: "coffee", quantity: 2, priceCents: 1 }],
      }),
    });
    assert.equal(response.status, 202);
    const created = await response.json();
    assert.equal(created.totalCents, 64000);
    await eventually(async () => {
      const orders = await (await fetch(`${ordersUrl}/api/orders`)).json();
      return orders.find(
        (order) => order.id === created.id && order.status === "invoiced",
      );
    });
    const invoices = await (await fetch(`${billingUrl}/api/invoices`)).json();
    const invoice = invoices.find((invoice) => invoice.order_id === created.id);
    assert.ok(invoice);
    assert.equal(Number(invoice.total_cents), 64000);
    const before = await consumedCount();
    const producer = new Kafka({
      clientId: "integration-test",
      brokers: (process.env.KAFKA_BROKERS || "localhost:29092").split(","),
      logLevel: logLevel.ERROR,
    }).producer();
    await producer.connect();
    try {
      const event = {
        id: created.eventId,
        type: "orders.created",
        version: 1,
        orderId: created.id,
        occurredAt: new Date().toISOString(),
        data: {
          customer: created.customer,
          items: created.items,
          totalCents: created.totalCents,
          currency: created.currency,
        },
      };
      await producer.send({
        topic: "orders.created",
        messages: [1, 2].map(() => ({
          key: created.id,
          value: JSON.stringify(event),
        })),
      });
      await eventually(async () => (await consumedCount()) >= before + 2);
      const after = await (await fetch(`${billingUrl}/api/invoices`)).json();
      assert.equal(
        after.filter((invoice) => invoice.order_id === created.id).length,
        1,
      );
    } finally {
      await producer.disconnect();
    }
  },
);
