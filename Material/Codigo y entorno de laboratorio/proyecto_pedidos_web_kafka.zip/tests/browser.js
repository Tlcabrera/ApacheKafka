import test from "node:test";
import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";

const baseUrl = process.env.FRONTEND_URL || "http://localhost:8080";

test(
  "architecture: interactive flow, partitions and consumer groups across screen sizes",
  { timeout: 90000 },
  async () => {
    const browser = await chromium.launch();
    try {
      for (const width of [1440, 1024, 768, 390, 320]) {
        const page = await browser.newPage({
          viewport: { width, height: 1000 },
        });
        const errors = [];
        page.on("pageerror", (error) => errors.push(error.message));
        await page.goto(baseUrl);
        await page
          .getByRole("navigation", { name: "Principal" })
          .getByRole("button", { name: "Arquitectura", exact: true })
          .click();
        await expect(
          page.getByRole("heading", { name: "Arquitectura." }),
        ).toBeVisible();
        await expect(
          page.getByRole("heading", {
            name: "Dos servicios. Un flujo de eventos.",
          }),
        ).toBeVisible();
        await expect(page.locator(".arch-partition-row")).toHaveCount(3);
        await expect(page.locator(".arch-log-cell")).toHaveCount(12);
        await expect(page.locator(".arch-group h3")).toHaveText("billing-v1");
        await page
          .getByRole("group", { name: "Topic ilustrado" })
          .getByRole("button", { name: "invoices.created" })
          .click();
        await expect(page.locator(".arch-group h3")).toHaveText("orders-v1");
        await page
          .getByRole("group", { name: "Cantidad ilustrativa de consumidores" })
          .getByRole("button", { name: "4", exact: true })
          .click();
        await expect(page.locator(".arch-consumer")).toHaveCount(4);
        await expect(page.locator(".arch-consumer.idle")).toHaveText(
          "C4Sin particion asignada",
        );
        await expect(page.locator(".arch-assignment")).toHaveText([
          "C1",
          "C2",
          "C3",
        ]);
        await page
          .getByRole("button", { name: "Paso 6: Factura idempotente" })
          .click();
        await expect(page.locator(".arch-step-detail h3")).toHaveText(
          "Billing crea una sola factura",
        );
        await page
          .getByRole("button", { name: "Paso siguiente", exact: true })
          .click();
        await expect(page.locator(".arch-step-detail h3")).toHaveText(
          "La confirmacion vuelve por Kafka",
        );
        await page.getByRole("button", { name: "Reiniciar recorrido" }).click();
        await expect(page.locator(".arch-step-count")).toHaveText("01 / 08");
        if (width === 1440) {
          await page
            .getByRole("button", { name: "Reproducir recorrido" })
            .click();
          await expect(page.locator(".arch-step-count")).toHaveText("02 / 08", {
            timeout: 5000,
          });
          await page.getByRole("button", { name: "Pausar recorrido" }).click();
        }
        const dimensions = await page.evaluate(() => ({
          viewport: innerWidth,
          content: document.documentElement.scrollWidth,
          overflowing: [
            ...document.querySelectorAll(
              ".architecture-view h2, .architecture-view h3, .arch-log-cell, .page-heading h1",
            ),
          ]
            .filter((element) => element.scrollWidth > element.clientWidth + 1)
            .map((element) => element.textContent),
        }));
        assert.ok(
          dimensions.content <= dimensions.viewport,
          `Architecture must not overflow at ${width}px: ${JSON.stringify(dimensions)}`,
        );
        assert.deepEqual(
          dimensions.overflowing,
          [],
          `Text must fit at ${width}px`,
        );
        const observabilityText = await page
          .locator(".arch-observability p")
          .boundingBox();
        assert.ok(
          observabilityText.width >= Math.min(220, width - 80),
          `Observability text must remain readable at ${width}px`,
        );
        await page.screenshot({
          path: `playwright-output/architecture-${width}.png`,
          fullPage: true,
        });
        assert.deepEqual(errors, []);
        await page.close();
      }
    } finally {
      await browser.close();
    }
  },
);

test(
  "desktop and mobile: create order, receive invoice, download and close dialogs",
  { timeout: 120000 },
  async () => {
    const browser = await chromium.launch();
    try {
      for (const viewport of [
        { width: 1440, height: 1000 },
        { width: 390, height: 844 },
      ]) {
        const page = await browser.newPage({ viewport });
        const errors = [];
        page.on("pageerror", (error) => errors.push(error.message));
        await page.goto(baseUrl);
        const customer = `Cliente UI ${viewport.width} ${Date.now()}`;
        await expect(
          page.getByRole("button", { name: "Nuevo pedido", exact: true }),
        ).toBeEnabled();
        const dimensions = await page.evaluate(() => ({
          viewport: innerWidth,
          content: document.documentElement.scrollWidth,
        }));
        assert.equal(dimensions.viewport, viewport.width);
        assert.ok(
          dimensions.content <= dimensions.viewport,
          "Page must not overflow horizontally",
        );
        await page
          .getByRole("button", { name: "Nuevo pedido", exact: true })
          .click();
        const dialog = page.getByRole("dialog");
        await expect(dialog).toBeVisible();
        const bounds = await dialog.boundingBox();
        assert.ok(bounds.x >= 0 && bounds.x + bounds.width <= viewport.width);
        await page
          .getByRole("textbox", { name: "Nombre del cliente" })
          .fill(customer);
        await page
          .getByRole("button", { name: "Agregar Cafe de origen", exact: true })
          .click();
        await expect
          .poll(
            () =>
              page
                .locator(".product-row img")
                .evaluateAll((images) =>
                  images.every(
                    (image) => image.complete && image.naturalWidth > 0,
                  ),
                ),
            { timeout: 20000 },
          )
          .toBe(true);
        await page.screenshot({
          path: `playwright-output/form-${viewport.width}.png`,
          fullPage: true,
        });
        const accepted = page.waitForResponse(
          (response) =>
            response.url().endsWith("/api/orders") &&
            response.request().method() === "POST",
        );
        await page
          .getByRole("button", { name: "Crear pedido", exact: true })
          .click();
        assert.equal((await accepted).status(), 202);
        await expect(dialog).toHaveCount(0);
        const row = page.locator("tbody tr").filter({ hasText: customer });
        await expect(row).toContainText("Facturado", { timeout: 30000 });
        await page.screenshot({
          path: `playwright-output/orders-${viewport.width}.png`,
          fullPage: true,
        });
        await page
          .getByRole("navigation", { name: "Principal" })
          .getByRole("button", { name: "Facturas", exact: true })
          .click();
        const invoiceRow = page
          .locator("tbody tr")
          .filter({ hasText: customer });
        await invoiceRow.getByRole("button").click();
        await expect(dialog).toBeVisible();
        const download = page.waitForEvent("download");
        await page.getByRole("button", { name: "Descargar JSON" }).click();
        assert.match((await download).suggestedFilename(), /^FAC-\d+\.json$/);
        await page.keyboard.press("Escape");
        await expect(dialog).toHaveCount(0);
        await page
          .getByRole("navigation", { name: "Principal" })
          .getByRole("button", { name: "Actividad" })
          .click();
        await expect(page.locator(".event-row").first()).toBeVisible();
        const activityDimensions = await page.evaluate(() => ({
          viewport: innerWidth,
          content: document.documentElement.scrollWidth,
        }));
        assert.ok(activityDimensions.content <= activityDimensions.viewport);
        assert.deepEqual(errors, []);
        await page.close();
      }
    } finally {
      await browser.close();
    }
  },
);
