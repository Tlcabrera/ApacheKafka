import test from "node:test";
import assert from "node:assert/strict";
import { createOrder } from "../services/orders/domain.js";

test("calculates totals from the server catalog, ignoring client prices", () => {
  const order = createOrder({
    customer: " Ana ",
    items: [{ productId: "coffee", quantity: 2, priceCents: 1 }],
  });
  assert.equal(order.totalCents, 64000);
  assert.equal(order.customer, "Ana");
  assert.equal(order.currency, "COP");
});

test("rejects invalid quantities, empty orders and unknown products", () => {
  for (const items of [
    [],
    [{ productId: "coffee", quantity: 0 }],
    [{ productId: "coffee", quantity: 1.5 }],
    [{ productId: "unknown", quantity: 1 }],
  ]) {
    assert.throws(() => createOrder({ customer: "Ana", items }));
  }
});
