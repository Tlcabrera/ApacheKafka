import { randomUUID } from "node:crypto";
import {
  createRuntime,
  transaction,
  enqueue,
  topics,
} from "../shared/runtime.js";
import { createOrder, products } from "./domain.js";

const { app, pool, subscribe, listen } = await createRuntime(
  "orders",
  "orders",
);
await pool.query(`CREATE TABLE IF NOT EXISTS orders.orders (
  id UUID PRIMARY KEY, customer TEXT NOT NULL, items JSONB NOT NULL,
  total_cents BIGINT NOT NULL CHECK (total_cents > 0), currency TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  invoice_id UUID, invoiced_at TIMESTAMPTZ, event_id UUID NOT NULL
)`);

app.get("/api/products", (req, res) => res.json(products));
app.get("/api/orders", async (req, res) => {
  const { rows } = await pool.query(
    "SELECT * FROM orders.orders ORDER BY created_at DESC LIMIT 100",
  );
  res.json(rows);
});
app.post("/api/orders", async (req, res) => {
  const order = createOrder(req.body);
  const id = randomUUID();
  const event = {
    id: randomUUID(),
    type: topics.orderCreated,
    version: 1,
    orderId: id,
    occurredAt: new Date().toISOString(),
    data: order,
  };
  await transaction(pool, async (client) => {
    await client.query(
      "INSERT INTO orders.orders (id, customer, items, total_cents, currency, event_id) VALUES ($1,$2,$3,$4,$5,$6)",
      [
        id,
        order.customer,
        JSON.stringify(order.items),
        order.totalCents,
        order.currency,
        event.id,
      ],
    );
    await enqueue(client, "orders", event);
  });
  res.status(202).json({ id, status: "pending", ...order, eventId: event.id });
});

await subscribe(topics.invoiceCreated, async (event) => {
  await pool.query(
    "UPDATE orders.orders SET status = 'invoiced', invoice_id = $1, invoiced_at = $2 WHERE id = $3 AND status = 'pending'",
    [event.data.invoiceId, event.occurredAt, event.orderId],
  );
});
listen(Number(process.env.PORT || 3001));
