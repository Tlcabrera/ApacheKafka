import { z } from "zod";

export const products = [
  {
    id: "coffee",
    name: "Cafe de origen",
    category: "DESPENSA",
    priceCents: 32000,
    image:
      "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=600&auto=format&fit=crop&q=80",
  },
  {
    id: "mug",
    name: "Taza de ceramica",
    category: "HOGAR",
    priceCents: 48000,
    image:
      "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=600&auto=format&fit=crop&q=80",
  },
  {
    id: "notebook",
    name: "Libreta de ideas",
    category: "PAPELERIA",
    priceCents: 24000,
    image:
      "https://images.unsplash.com/photo-1531346878377-a5be20888e57?w=600&auto=format&fit=crop&q=80",
  },
];

const orderSchema = z.object({
  customer: z.string().trim().min(2).max(100),
  items: z
    .array(
      z.object({
        productId: z.enum(["coffee", "mug", "notebook"]),
        quantity: z.number().int().min(1).max(50),
      }),
    )
    .min(1)
    .max(20),
});

export function createOrder(input) {
  const parsed = orderSchema.parse(input);
  const items = parsed.items.map((item) => {
    const product = products.find((product) => product.id === item.productId);
    return { ...item, name: product.name, priceCents: product.priceCents };
  });
  return {
    customer: parsed.customer,
    items,
    totalCents: items.reduce(
      (total, item) => total + item.priceCents * item.quantity,
      0,
    ),
    currency: "COP",
  };
}
