import express from "express";
import pg from "pg";
import { Kafka, logLevel } from "kafkajs";
import {
  Registry,
  collectDefaultMetrics,
  Counter,
  Histogram,
} from "prom-client";

export const topics = {
  orderCreated: "orders.created",
  invoiceCreated: "invoices.created",
};

export async function createRuntime(service, schema) {
  const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
  await pool.query(`CREATE SCHEMA IF NOT EXISTS ${schema}`);
  await pool.query(`CREATE TABLE IF NOT EXISTS ${schema}.outbox (
    id UUID PRIMARY KEY, topic TEXT NOT NULL, event_key TEXT NOT NULL,
    payload JSONB NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), published_at TIMESTAMPTZ
  )`);
  const kafka = new Kafka({
    clientId: service,
    brokers: (process.env.KAFKA_BROKERS || "localhost:29092").split(","),
    logLevel: logLevel.WARN,
  });
  const admin = kafka.admin();
  await admin.connect();
  await admin.createTopics({
    waitForLeaders: true,
    topics: Object.values(topics).map((topic) => ({
      topic,
      numPartitions: 3,
      replicationFactor: 1,
    })),
  });
  const producer = kafka.producer({
    allowAutoTopicCreation: false,
    idempotent: true,
    maxInFlightRequests: 1,
  });
  await producer.connect();
  const consumer = kafka.consumer({
    groupId: `${service}-v1`,
    allowAutoTopicCreation: false,
  });
  const registry = new Registry();
  registry.setDefaultLabels({ service });
  collectDefaultMetrics({ register: registry });
  const published = new Counter({
    name: "events_published_total",
    help: "Events acknowledged by Kafka",
    labelNames: ["topic"],
    registers: [registry],
  });
  const consumed = new Counter({
    name: "events_consumed_total",
    help: "Successfully handled events",
    labelNames: ["topic"],
    registers: [registry],
  });
  const failures = new Counter({
    name: "outbox_publish_failures_total",
    help: "Failed outbox publish attempts",
    registers: [registry],
  });
  const requests = new Histogram({
    name: "http_request_duration_seconds",
    help: "HTTP request duration",
    labelNames: ["method", "route", "status"],
    registers: [registry],
    buckets: [0.01, 0.05, 0.1, 0.5, 1, 3],
  });
  const app = express();
  app.disable("x-powered-by");
  app.use(express.json({ limit: "32kb" }));
  app.use((req, res, next) => {
    const stop = requests.startTimer();
    res.on("finish", () =>
      stop({
        method: req.method,
        route: req.route?.path || "unmatched",
        status: String(res.statusCode),
      }),
    );
    next();
  });
  app.get("/health", async (req, res) => {
    try {
      await pool.query("SELECT 1");
      await admin.fetchTopicMetadata({ topics: Object.values(topics) });
      res.json({ status: "up", service });
    } catch {
      res.status(503).json({ status: "down", service });
    }
  });
  app.get("/metrics", async (req, res) =>
    res.type(registry.contentType).send(await registry.metrics()),
  );
  let stopping = false;
  let publishing = false;
  let activePublish = Promise.resolve();
  async function publishPending() {
    if (publishing || stopping) return;
    publishing = true;
    try {
      const { rows } = await pool.query(
        `SELECT * FROM ${schema}.outbox WHERE published_at IS NULL ORDER BY created_at LIMIT 50`,
      );
      for (const row of rows) {
        await producer.send({
          topic: row.topic,
          messages: [
            { key: row.event_key, value: JSON.stringify(row.payload) },
          ],
        });
        await pool.query(
          `UPDATE ${schema}.outbox SET published_at = NOW() WHERE id = $1`,
          [row.id],
        );
        published.inc({ topic: row.topic });
      }
    } catch (error) {
      failures.inc();
      console.error(
        JSON.stringify({
          service,
          message: "Outbox publish failed; will retry",
          error: error.message,
        }),
      );
    } finally {
      publishing = false;
    }
  }
  const interval = setInterval(() => {
    if (!publishing && !stopping) activePublish = publishPending();
  }, 1000);
  async function subscribe(topic, handler) {
    await consumer.connect();
    await consumer.subscribe({ topic, fromBeginning: true });
    await consumer.run({
      eachMessage: async ({ message }) => {
        const event = JSON.parse(message.value.toString());
        await handler(event);
        consumed.inc({ topic });
      },
    });
  }
  function listen(port) {
    app.use((error, req, res, next) => {
      console.error(JSON.stringify({ service, error: error.message }));
      const status =
        error.name === "ZodError" || error.type === "entity.parse.failed"
          ? 400
          : error.status || 500;
      res.status(status).json({
        error:
          status < 500
            ? "Datos invalidos. Revisa el cliente y las cantidades."
            : "Error interno del servicio.",
      });
    });
    const server = app.listen(port, "0.0.0.0", () =>
      console.log(`${service} listening on ${port}`),
    );
    async function shutdown() {
      if (stopping) return;
      stopping = true;
      clearInterval(interval);
      server.close();
      await consumer.disconnect();
      await activePublish;
      await producer.disconnect();
      await admin.disconnect();
      await pool.end();
    }
    process.on("SIGTERM", () => shutdown().catch(console.error));
    process.on("SIGINT", () => shutdown().catch(console.error));
  }
  return { app, pool, subscribe, listen };
}

export async function transaction(pool, handler) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await handler(client);
    await client.query("COMMIT");
    return result;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

export async function enqueue(client, schema, event) {
  await client.query(
    `INSERT INTO ${schema}.outbox (id, topic, event_key, payload) VALUES ($1, $2, $3, $4)`,
    [event.id, event.type, event.orderId, event],
  );
}
