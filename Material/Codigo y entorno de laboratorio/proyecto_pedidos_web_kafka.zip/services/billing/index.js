import { randomUUID } from "node:crypto";
import {
  createRuntime,
  transaction,
  enqueue,
  topics,
} from "../shared/runtime.js";

const { app, pool, subscribe, listen } = await createRuntime(
  "billing",
  "billing",
);
await pool.query(`CREATE TABLE IF NOT EXISTS billing.invoices (
  id UUID PRIMARY KEY, number BIGINT GENERATED ALWAYS AS IDENTITY UNIQUE,
  order_id UUID NOT NULL UNIQUE, customer TEXT NOT NULL, items JSONB NOT NULL,
  total_cents BIGINT NOT NULL CHECK (total_cents > 0), currency TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), source_event_id UUID NOT NULL
)`);
app.get("/api/invoices", async (req, res) => {
  const { rows } = await pool.query(
    "SELECT * FROM billing.invoices ORDER BY created_at DESC LIMIT 100",
  );
  res.json(rows);
});

await subscribe(topics.orderCreated, async (event) => {
  if (event.type !== topics.orderCreated || event.version !== 1)
    throw new Error("Unsupported order event");
  await transaction(pool, async (client) => {
    const invoiceId = randomUUID();
    const { rows } = await client.query(
      `INSERT INTO billing.invoices (id, order_id, customer, items, total_cents, currency, source_event_id)
      VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT (order_id) DO NOTHING RETURNING id`,
      [
        invoiceId,
        event.orderId,
        event.data.customer,
        JSON.stringify(event.data.items),
        event.data.totalCents,
        event.data.currency,
        event.id,
      ],
    );
    if (!rows.length) return;
    await enqueue(client, "billing", {
      id: randomUUID(),
      type: topics.invoiceCreated,
      version: 1,
      orderId: event.orderId,
      occurredAt: new Date().toISOString(),
      data: {
        invoiceId,
        totalCents: event.data.totalCents,
        currency: event.data.currency,
      },
    });
  });
});
listen(Number(process.env.PORT || 3002));
