# Pedido Flow

Demo de arquitectura orientada a eventos (EDA): un frontend React y **exactamente dos backends Express**, conectados mediante Kafka. Sin login. Los datos se guardan en PostgreSQL.

## Arranque desde git clone

### 1. Preparar la maquina

- Instala Git y Docker Desktop. En Windows, habilita WSL 2 y usa contenedores Linux.
- Abre Docker Desktop y espera a que el motor este disponible.
- Como referencia para esta demo, deja al menos 4 GB de memoria disponibles para Docker y espacio para descargar las imagenes.
- Comprueba que tienes Docker Compose v2 y conexion a Internet para el primer build.

```powershell
git --version
docker version
docker compose version
```

`docker version` debe mostrar tanto **Client** como **Server**. Si falta Server, inicia Docker Desktop antes de continuar. No necesitas instalar Node, npm, PostgreSQL ni Kafka en tu maquina para ejecutar la demo con Docker: todo se construye dentro de contenedores.

### 2. Clonar el repositorio

Sustituye la URL de ejemplo por la URL real de tu repositorio. El segundo argumento crea una carpeta local llamada `pedido-flow`, independientemente del nombre del repositorio remoto.

```powershell
git clone https://github.com/TU_USUARIO/TU_REPOSITORIO.git pedido-flow
cd pedido-flow
```

Todos los comandos siguientes se ejecutan desde esa carpeta, donde se encuentra [compose.yaml](compose.yaml). No hay que copiar configuraciones ni crear archivos de variables de entorno: Compose ya incluye la configuracion local de demostracion.

### 3. Validar y arrancar

```powershell
docker compose config --quiet
docker compose up --build --wait --wait-timeout 240
```

El primer comando valida la configuracion sin imprimir las credenciales de ejemplo. El segundo descarga las imagenes, construye los dos backends y el frontend, crea la red y los volumenes, y arranca los ocho contenedores. `--wait` deja los servicios en segundo plano y espera a que esten ejecutandose o saludables, segun su configuracion.

PostgreSQL y Kafka arrancan antes de los backends; el frontend espera a que ambos backends esten saludables. Las tablas, los topics, la fuente de datos de Grafana y el dashboard se crean o provisionan automaticamente. No tienes que crear manualmente topics ni importar dashboards.

La primera ejecucion puede tardar varios minutos por las descargas y compilaciones. El timeout de 240 segundos se aplica a la espera de los servicios, no es un limite total de descarga y build.

### 4. Comprobar el estado

```powershell
docker compose ps
docker compose logs --tail=50 orders billing
```

Los servicios deben estar en estado `Up` o `running`; los que tienen health check, como Kafka, PostgreSQL y los backends, deben pasar a `healthy`. Si falla alguno, revisa sus logs antes de volver a ejecutar el comando de arranque.

### 5. Abrir la aplicacion

Los siguientes puertos del host deben estar libres:

| Componente                      | URL                                 |
| ------------------------------- | ----------------------------------- |
| Aplicacion                      | http://localhost:8080               |
| API de pedidos                  | http://localhost:3001/api/orders    |
| API de facturas                 | http://localhost:3002/api/invoices  |
| Kafbat UI                       | http://localhost:18081              |
| Grafana, dashboard provisionado | http://localhost:3000/d/pedido-flow |
| Prometheus                      | http://localhost:9090               |

Grafana abre en modo anonimo de solo lectura. Kafbat permite inspeccionar topics, mensajes, particiones, consumer groups y offsets. PostgreSQL no publica un puerto en el host.

Kafka tambien publica `localhost:29092` para las pruebas que se ejecutan desde tu maquina; no es una pagina web. Entre contenedores, los servicios usan `kafka:9092`, no `localhost`.

### 6. Crear el primer pedido

1. Abre http://localhost:8080 y selecciona **Nuevo pedido**, o pulsa **Generar 5 pedidos**.
2. Espera el cambio de `Pendiente` a `Facturado`. No es instantaneo: intervienen los publicadores outbox, Kafka y la consulta periodica del frontend.
3. En **Facturas**, abre un comprobante y descarga su JSON.
4. En **Arquitectura**, recorre el mapa interactivo y el ejemplo de particiones y consumidores. Es una explicacion ilustrativa: no cambia la configuracion del cluster.
5. Abre Grafana y espera al menos un minuto para observar tasas y percentiles con varias muestras. Genera varios lotes separados en el tiempo.

## Arquitectura

```mermaid
flowchart LR
  UI[React + Vite] -->|HTTP| O[Express: pedidos]
  UI -->|HTTP consulta| B[Express: facturacion]
  O -->|pedido + outbox en transaccion| OP[(PostgreSQL: orders)]
  OP -->|publicador outbox| OC[Kafka: orders.created]
  OC -->|consumer billing-v1| B
  B -->|factura + outbox en transaccion| BP[(PostgreSQL: billing)]
  BP -->|publicador outbox| IC[Kafka: invoices.created]
  IC -->|consumer orders-v1| O
  P[Prometheus] -->|/metrics| O
  P -->|/metrics| B
  G[Grafana] --> P
  K[Kafbat UI] --> OC
  K --> IC
```

1. El frontend crea un pedido. Pedidos valida cantidades y calcula precios desde su catalogo, en centavos enteros de COP.
2. Pedidos guarda el pedido y `orders.created` en una misma transaccion. Responde `202 Accepted`: aceptado no significa facturado.
3. Un publicador revisa el outbox cada segundo y publica los eventos pendientes en Kafka. Solo marca publicado despues del ACK del broker.
4. Facturacion consume el evento y guarda la factura y `invoices.created` en una transaccion propia.
5. Pedidos consume la confirmacion y cambia de `pending` a `invoiced`. El frontend consulta cada tres segundos.

Cada evento incluye `id`, `type`, `version`, `orderId`, `occurredAt` y `data`. La clave Kafka es `orderId`, para conservar el orden por pedido dentro de cada topic. Cada topic tiene tres particiones.

**Garantia: entrega al menos una vez, no exactly-once.** Si un proceso cae entre publicar y marcar el outbox, puede repetir el evento. La restriccion `UNIQUE(order_id)` evita facturas duplicadas y la actualizacion de pedidos es idempotente. El offset se confirma despues de manejar el mensaje; los fallos de consumo se reintentan mediante KafkaJS. No hay llamadas HTTP entre backends.

Una instancia PostgreSQL aloja dos esquemas: cada servicio usa exclusivamente sus tablas. Comparten credenciales para simplificar la demo, no como aislamiento de seguridad. Las tablas se crean al iniciar; no hay framework de migraciones. **Ejecutar una replica por servicio:** el publicador outbox no implementa coordinacion entre multiples replicas.

## Especificacion tecnica

### Componentes y tecnologias

| Componente              | Tecnologia                         | Responsabilidad                                                                                        |
| ----------------------- | ---------------------------------- | ------------------------------------------------------------------------------------------------------ |
| Frontend                | React 19, Vite 8, Lucide           | Pedidos, facturas, actividad y mapa de arquitectura. Consulta las APIs cada 3 segundos.                |
| Servidor web            | Nginx 1.28 Alpine                  | Sirve el build estatico y redirige `/api` al backend correspondiente.                                  |
| Pedidos (`orders`)      | Node 22 Alpine, Express 5, KafkaJS | Valida pedidos con Zod, calcula precios, persiste y publica `orders.created`; consume la confirmacion. |
| Facturacion (`billing`) | Node 22 Alpine, Express 5, KafkaJS | Consume pedidos, genera facturas idempotentes y publica `invoices.created`.                            |
| Base de datos           | PostgreSQL 17 Alpine, cliente `pg` | Base `commerce`, esquemas `orders` y `billing`.                                                        |
| Broker de eventos       | Apache Kafka 3.9.1                 | Un nodo en modo KRaft, con funciones de broker y controller. Sin ZooKeeper.                            |
| Explorador Kafka        | Kafbat UI 1.2.0                    | Inspeccion de topics, mensajes, particiones, grupos y offsets.                                         |
| Recoleccion de metricas | Prometheus 3.4.1, `prom-client`    | Consulta `/metrics` de cada backend cada 5 segundos.                                                   |
| Visualizacion           | Grafana 12.0.2                     | Fuente Prometheus y dashboard provisionados; refresco de 5 segundos, rango inicial de 15 minutos.      |

Son **ocho servicios de Compose** y **dos backends de negocio**. Nginx forma parte del contenedor frontend, no es un backend adicional. Las dependencias npm exactas se resuelven desde [package-lock.json](package-lock.json); las imagenes y los puertos se definen en [compose.yaml](compose.yaml).

### APIs HTTP

| Servicio    | Metodo y ruta       | Resultado                                                                                                                 |
| ----------- | ------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| Pedidos     | `GET /api/products` | Catalogo con identificadores y precios calculados por el servidor.                                                        |
| Pedidos     | `POST /api/orders`  | Valida y guarda pedido + outbox; responde `202 Accepted` con el identificador y estado `pending`. Datos invalidos: `400`. |
| Pedidos     | `GET /api/orders`   | Ultimos 100 pedidos, del mas reciente al mas antiguo.                                                                     |
| Facturacion | `GET /api/invoices` | Ultimas 100 facturas. No existe un endpoint HTTP para emitir una factura: la emision la dispara Kafka.                    |
| Ambos       | `GET /health`       | Comprueba PostgreSQL y acceso a los metadatos de los topics. Devuelve `200` o `503`.                                      |
| Ambos       | `GET /metrics`      | Metricas en formato Prometheus. No requiere login.                                                                        |

Ejemplo para crear un pedido desde PowerShell:

```powershell
$body = @{
  customer = 'Laura Martinez'
  items = @(@{ productId = 'coffee'; quantity = 2 })
} | ConvertTo-Json -Depth 4

Invoke-RestMethod -Method Post -Uri 'http://localhost:3001/api/orders' -ContentType 'application/json' -Body $body
```

El cliente no decide el precio. Los importes se manejan en **centavos enteros de COP** para evitar errores de coma flotante; por ejemplo, `64000` centavos se muestran como `640 COP`. Un `202` solo confirma que el pedido y su outbox estan guardados, no que la factura ya exista.

### Topics, particiones y consumidores

| Topic              | Productor | Grupo consumidor | Efecto al consumir                                                           |
| ------------------ | --------- | ---------------- | ---------------------------------------------------------------------------- |
| `orders.created`   | `orders`  | `billing-v1`     | Crear factura y registrar el evento de confirmacion en el outbox de billing. |
| `invoices.created` | `billing` | `orders-v1`      | Actualizar el pedido a `invoiced`, con el identificador de factura.          |

- Cada topic se crea con **3 particiones** y **factor de replicacion 1**. Las particiones reparten mensajes, no son tres copias del mismo evento.
- El productor envia `orderId` como clave. El particionador de KafkaJS elige una particion; manteniendo el numero de particiones, una misma clave conserva su particion dentro de ese topic.
- El orden esta garantizado dentro de una particion, no globalmente entre particiones ni entre topics.
- Cada grupo tiene un consumidor en esta demo, que recibe las tres particiones de su topic. Una particion solo se asigna a un miembro del mismo grupo a la vez.
- Tres particiones permitirian asignar trabajo a un maximo de tres miembros del grupo. Esto no significa que el backend actual soporte tres replicas: su publicador outbox no coordina multiples instancias.
- El offset es la posicion del mensaje en una particion. Cada grupo conserva su avance; consumir no borra el mensaje, que permanece segun la retencion de Kafka.
- La suscripcion usa `fromBeginning: true` cuando el grupo no tiene un offset guardado; si ya lo tiene, reanuda desde ese avance.

Sobre de un evento de pedido, con valores de ejemplo:

```json
{
  "id": "00000000-0000-4000-8000-000000000001",
  "type": "orders.created",
  "version": 1,
  "orderId": "00000000-0000-4000-8000-000000000002",
  "occurredAt": "2026-11-12T12:00:00.000Z",
  "data": {
    "customer": "Laura Martinez",
    "items": [
      {
        "productId": "coffee",
        "quantity": 2,
        "name": "Cafe de origen",
        "priceCents": 32000
      }
    ],
    "totalCents": 64000,
    "currency": "COP"
  }
}
```

La confirmacion mantiene el mismo `orderId`, usa `type: invoices.created` y lleva `invoiceId`, `totalCents` y `currency` en `data`.

### Persistencia y configuracion

| Tablas             | Datos y garantia principal                                                                     |
| ------------------ | ---------------------------------------------------------------------------------------------- |
| `orders.orders`    | Cliente, productos, total, estado y referencia de factura. Identificador UUID.                 |
| `orders.outbox`    | Eventos de pedidos pendientes o publicados; `published_at` registra la publicacion confirmada. |
| `billing.invoices` | Comprobante con numero generado y `UNIQUE(order_id)` para evitar facturas duplicadas.          |
| `billing.outbox`   | Eventos de confirmacion registrados en la misma transaccion que la factura.                    |

Los dos publicadores consultan sus outbox cada segundo, en lotes de hasta 50 eventos. No hay transaccion distribuida entre PostgreSQL y Kafka: por eso se admite reentrega y se aplica idempotencia.

Variables principales de los backends, ya configuradas por Compose:

| Variable        | Valor en la demo                                                       |
| --------------- | ---------------------------------------------------------------------- |
| `DATABASE_URL`  | Conexion a `postgres:5432`, base `commerce`, usuario local de ejemplo. |
| `KAFKA_BROKERS` | `kafka:9092` dentro de la red de Compose.                              |
| `PORT`          | `3001` en orders y `3002` en billing.                                  |

Los volumenes `postgres-data`, `kafka-data`, `prometheus-data` y `grafana-data` conservan datos entre reinicios. Cambiar una variable de inicializacion de PostgreSQL no modifica automaticamente una base que ya existe en un volumen.

## Guion de demostracion

1. Abre la aplicacion y pulsa **Generar 5 pedidos**, o crea uno manualmente seleccionando productos.
2. Observa el paso de pendiente a facturado. Selecciona un pedido para consultar su recorrido.
3. Abre Kafbat, selecciona el cluster y revisa `orders.created`, `invoices.created` y los grupos `billing-v1` y `orders-v1`.
4. Abre Grafana: disponibilidad de los procesos, eventos publicados/consumidos, errores de outbox y latencia HTTP p95. Genera varios lotes para ver las tasas. Los contadores son por proceso y se reinician al reiniciar el servicio.
5. Deten facturacion:

```powershell
docker compose stop billing
```

6. Crea mas pedidos. Se aceptan y permanecen pendientes aunque facturacion este detenida. El frontend indicara conexion parcial. En Kafbat podras ver los mensajes sin consumir.
7. Recupera el consumidor:

```powershell
docker compose start billing
```

8. Los pedidos pendientes se facturan sin volver a crearlos. Para comprobar duplicados de manera reproducible, ejecuta la prueba de integracion.

## Grafana: que muestra cada grafica

Abre http://localhost:3000/d/pedido-flow. No hay que iniciar sesion ni importar el dashboard: [overview.json](infra/grafana/dashboards/overview.json) y la fuente de datos se provisionan al arrancar. El acceso anonimo es de solo lectura.

El dashboard refresca cada **5 segundos** y muestra inicialmente los ultimos **15 minutos**. Las cuatro cifras superiores son paneles de valor; las dos inferiores son series temporales. Selecciona un rango que incluya tus pedidos y genera varios lotes para observar cambios.

### 1. Servicios disponibles

```promql
sum(up{job=~"orders|billing"})
```

Cuenta los backends cuyo endpoint de metricas Prometheus puede consultar: normalmente **2**; si uno deja de responder, **1**; si ambos fallan, **0**, siempre que los targets esten configurados y ya hayan sido evaluados.

**No mide todo el sistema.** No incluye Kafka, PostgreSQL ni el frontend como targets independientes. Un proceso puede servir `/metrics` y tener problemas con Kafka: `up = 1` no garantiza que `/health` responda `200`, que el consumidor avance o que se esten creando facturas.

### 2. Eventos publicados

```promql
sum(events_published_total) or vector(0)
```

Suma el contador de publicaciones completadas por ambos backends. Se incrementa despues de enviar a Kafka y marcar el outbox como publicado. Un pedido facturado produce normalmente **dos publicaciones**: `orders.created` e `invoices.created`.

No equivale al numero de pedidos ni es un total historico de la base de datos. El contador es por proceso y se reinicia al reiniciar su backend. El valor cero de respaldo tambien puede aparecer si no hay series: confirma la disponibilidad antes de interpretarlo como ausencia de actividad.

### 3. Eventos consumidos

```promql
sum(events_consumed_total) or vector(0)
```

Cuenta ejecuciones del manejador de eventos terminadas correctamente: billing consume el pedido y orders consume su confirmacion. Un ciclo normal aporta dos consumos. Una reentrega idempotente tambien cuenta como consumo correcto aunque no cree otra factura; por eso esta cifra puede diferir de las publicaciones y de las facturas.

### 4. Fallos de publicacion

```promql
sum(outbox_publish_failures_total) or vector(0)
```

Cuenta intentos fallidos del ciclo de publicacion outbox, por ejemplo por problemas con Kafka o PostgreSQL durante ese ciclo. Lo esperado en operacion normal es **0**. Una subida indica fallos; el publicador vuelve a intentar enviar lo pendiente en sus siguientes ciclos.

No cuenta eventos perdidos ni todos los errores de consumo o HTTP. Un ciclo fallido puede dejar varios eventos pendientes: no hay correspondencia uno a uno entre fallos y mensajes.

### 5. Eventos / segundo

```promql
sum by (topic) (rate(events_published_total[1m]))
```

Grafica la tasa promedio de publicaciones por segundo durante el ultimo minuto, separada por topic. Al generar pedidos aparece actividad en `orders.created` y despues en `invoices.created`.

Por ejemplo, cinco publicaciones repartidas aproximadamente en un minuto representan alrededor de `0.083 eventos/s`; no significa que exista una fraccion de mensaje. `rate` estima una tasa y corrige reinicios de contadores. Con pocos datos, extrapolacion en los extremos o una ventana distinta, el valor puede variar.

Si detienes billing y creas pedidos, deberias ver actividad de pedidos sin sus confirmaciones correspondientes. Al recuperar billing puede aparecer un pico de `invoices.created` mientras procesa los pendientes.

### 6. Latencia HTTP p95 (segundos)

```promql
histogram_quantile(
  0.95,
  sum by (le, service) (
    rate(http_request_duration_seconds_bucket{route!~"/metrics|/health"}[1m])
  )
)
```

Estima por servicio el tiempo por debajo del cual termina aproximadamente el **95 % de las solicitudes HTTP**, usando las muestras del ultimo minuto. Excluye las rutas de salud y metricas. Un valor de `0.05` equivale a **50 ms**.

No es la media, el peor caso ni el tiempo completo entre crear pedido y generar factura. Combina las rutas HTTP de cada servicio. Es una estimacion a partir de buckets del histograma; sin solicitudes en la ventana puede aparecer `NaN` o un hueco. Los buckets finitos configurados son `0.01`, `0.05`, `0.1`, `0.5`, `1` y `3` segundos, por lo que la precision es limitada.

### Interpretacion y limites

- Los contadores son memoria del proceso, no auditoria persistida. Para cambios dentro de una ventana usa `increase`; para tasa, `rate`. No restes contadores manualmente a traves de un reinicio.
- `or vector(0)` evita un panel vacio, pero puede ocultar la falta de una serie. Revisa primero los targets y `up`.
- Las metricas con etiqueta `topic` pueden no existir hasta que ocurra el primer evento. Las tasas requieren al menos dos muestras; espera varios scrapes tras generar actividad.
- Las series publicadas y consumidas se actualizan de forma asincrona. Su diferencia **no es el lag de Kafka**: hay reentregas, reinicios y desfase de scrapes.
- Este proyecto no incluye un exporter de Kafka ni de PostgreSQL. Las metricas internas del broker, su disco o el lag por grupo no aparecen en Grafana; inspecciona el lag en Kafbat.
- La pantalla de operaciones limita sus listas y resumenes a 100 registros. Es normal que sus cifras no coincidan con los contadores de Prometheus.

## Prometheus: consultas de ejemplo

1. Abre http://localhost:9090/query.
2. Pega una consulta PromQL y ejecutala. Usa la vista de tabla para valores actuales o la grafica para su evolucion.
3. Para tasas y percentiles, genera pedidos y elige una ventana temporal con actividad. Puedes usar todas las consultas anteriores y los ejemplos siguientes.
4. Revisa http://localhost:9090/targets: los jobs `orders` y `billing` deberian estar `UP`.

### Disponibilidad por backend

```promql
up{job=~"orders|billing"}
```

Devuelve una serie por target: `1` si el scrape funciona, `0` si falla. La etiqueta `job` identifica el backend.

### Publicaciones por servicio y topic

```promql
sum by (service, topic) (events_published_total)
```

Lo habitual es `service="orders", topic="orders.created"` y `service="billing", topic="invoices.created"`. Son contadores desde el arranque de cada proceso, no cantidades dentro del rango seleccionado en la pantalla.

### Publicaciones estimadas en los ultimos cinco minutos

```promql
sum by (topic) (increase(events_published_total[5m]))
```

`increase` estima el aumento del contador y tiene en cuenta reinicios. Puede devolver decimales por extrapolacion; no es un conteo contable exacto de mensajes o pedidos.

### Consumos por segundo, separados por servicio

```promql
sum by (service, topic) (rate(events_consumed_total[5m]))
```

Permite observar que billing maneja `orders.created` y orders maneja `invoices.created`. La ventana de cinco minutos suaviza picos respecto al minuto usado por el dashboard.

### Nuevos fallos de outbox por servicio

```promql
sum by (service) (increase(outbox_publish_failures_total[5m]))
```

Un valor mayor que cero indica intentos fallidos en esa ventana. Usa los logs del backend para conocer el motivo.

### Solicitudes de creacion de pedidos por segundo

```promql
sum(rate(http_request_duration_seconds_count{service="orders",method="POST",route="/api/orders"}[5m]))
```

Incluye las solicitudes a esa ruta con sus distintos codigos HTTP. No equivale necesariamente a pedidos creados: una solicitud invalidada con `400` tambien se mide.

### Respuestas HTTP 5xx por segundo

```promql
sum(rate(http_request_duration_seconds_count{status=~"5.."}[5m])) or vector(0)
```

Sirve para detectar errores HTTP registrados por los backends. Cero no demuestra que Kafka este saludable: la comunicacion asincrona no pasa por HTTP.

Para ver las muestras sin PromQL, abre http://localhost:3001/metrics o http://localhost:3002/metrics. Encontraras etiquetas como `service`, `topic`, `method`, `route` y `status` segun la metrica. Prometheus agrega `job` e `instance` al recolectarlas. Tambien se exponen metricas predeterminadas del proceso Node.

## Desarrollo y pruebas

```powershell
npm ci
npm test
npm run check
npm run lint --workspace frontend
npm run build
npm run test:integration
```

Prueba de interfaz en Chromium, con capturas en `playwright-output/`:

```powershell
npx playwright install chromium
npm run test:ui
```

Requiere Compose levantado y conexion a Internet para comprobar las imagenes de productos. Recorre escritorio y movil: creacion de pedido, confirmacion, factura, descarga JSON y cierre con Escape.

La prueba de integracion requiere Compose levantado. Crea un pedido real, espera su factura, publica dos veces el mismo evento y comprueba que el consumidor los manejo sin crear otra factura. Deja sus registros visibles en la demo.

Para trabajar en el frontend con recarga automatica, conserva los backends en Docker y ejecuta:

```powershell
npm run dev
```

Vite muestra la URL disponible (normalmente http://localhost:5173) y redirige `/api` a los backends locales. Para ejecutar backends fuera de Docker, configura `DATABASE_URL`, `KAFKA_BROKERS` y opcionalmente `PORT`; PostgreSQL requiere entonces un puerto accesible desde tu maquina. La modalidad recomendada es ejecutar los backends en Compose.

Consultar tablas sin exponer PostgreSQL:

```powershell
docker compose exec postgres psql -U demo -d commerce -c "SELECT id, customer, status FROM orders.orders;"
docker compose exec postgres psql -U demo -d commerce -c "SELECT number, order_id, total_cents FROM billing.invoices;"
docker compose logs -f orders billing
```

Ambos servicios exponen `/health` (comprueba PostgreSQL y conectividad al broker) y `/metrics`. Prometheus mide los backends, no las metricas internas del broker; para estas se podria incorporar un exporter en una ampliacion. `up` indica que el scrape HTTP funciona, no que un consumidor este progresando. Kafbat permite revisar su lag.

## Operacion y solucion de problemas

### Reiniciar, actualizar y detener

Reiniciar los contenedores existentes conservando sus datos:

```powershell
docker compose restart
```

Despues de descargar cambios del repositorio, reconstruir y aplicar el estado de Compose:

```powershell
git pull
docker compose up --build --wait --wait-timeout 240
```

`restart` por si solo no reconstruye imagenes ni aplica cambios de configuracion. Para detener y retirar contenedores y red:

```powershell
docker compose down
```

Los datos se conservan en volumenes. `docker compose down -v` elimina **todos** los datos de esta demo.

### Diagnostico rapido

| Sintoma                                            | Que revisar                                                                                                                                                                                                                                                                                |
| -------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| No se puede conectar al daemon Docker              | Iniciar Docker Desktop y comprobar que `docker version` muestra Server.                                                                                                                                                                                                                    |
| Puerto ocupado o acceso al socket denegado         | Revisar los puertos de la tabla de arranque y las reservas de Windows. Cambiar solo el puerto del host en Compose si hace falta; si cambias los puertos de las herramientas, actualizar tambien los enlaces del frontend. No es necesario cambiar los puertos internos entre contenedores. |
| Un servicio no pasa a healthy o vence el timeout   | Ejecutar `docker compose ps` y `docker compose logs --tail=100 kafka postgres orders billing`. Resolver el fallo y repetir `docker compose up --build --wait --wait-timeout 240`.                                                                                                          |
| El pedido queda pendiente                          | Revisar el estado y los logs de billing, los mensajes de `orders.created` y el lag de `billing-v1` en Kafbat. No crear de nuevo el pedido solo por estar pendiente.                                                                                                                        |
| Grafana muestra No data                            | Crear pedidos, esperar varias muestras, revisar el rango temporal y comprobar los targets de Prometheus. Un hueco del p95 sin solicitudes no implica una averia.                                                                                                                           |
| Se cambio el codigo pero sigue la version anterior | Reconstruir con `docker compose up --build --wait --wait-timeout 240`; no basta con reiniciar el contenedor.                                                                                                                                                                               |
| Se quieren datos completamente nuevos              | `docker compose down -v` borra pedidos, facturas, eventos y datos de observabilidad. Usarlo solo si se acepta perder toda la demo; despues arrancar de nuevo.                                                                                                                              |

## Limitaciones

No desplegar en Internet: sin autenticacion, TLS ni ACL, con credenciales locales de ejemplo. Los puertos publicados estan ligados a `127.0.0.1`. Kafka es de un solo broker y no ofrece alta disponibilidad. No se incluyen pagos, inventario, impuestos ni facturacion fiscal: las facturas son comprobantes de demostracion. Los endpoints y contadores de la pantalla muestran los ultimos 100 registros, no totales historicos.

Para mantener el alcance pequeno no se implementan DLQ, validacion completa del contrato de eventos entrantes, reintentos HTTP idempotentes, retencion/limpieza del outbox ni migraciones versionadas. Un mensaje malformado puede bloquear su particion y requerir intervencion en Kafbat; no se descarta silenciosamente. Las imagenes de productos (Unsplash) y tipografias (Google Fonts) requieren conexion a Internet; el flujo de pedidos no depende de ellas.
