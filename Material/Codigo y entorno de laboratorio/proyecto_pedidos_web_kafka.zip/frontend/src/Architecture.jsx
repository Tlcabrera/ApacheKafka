import { useEffect, useState } from "react";
import {
  Activity,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  CheckCheck,
  Database,
  FileCheck2,
  FileText,
  GitBranch,
  Layers3,
  Monitor,
  Pause,
  Play,
  Radio,
  RotateCcw,
  Server,
  ShieldCheck,
  ShoppingBag,
  Users,
} from "lucide-react";
import "./architecture.css";

const steps = [
  {
    title: "El cliente crea un pedido",
    label: "Solicitud HTTP",
    icon: Monitor,
    node: "frontend",
    tag: "POST /api/orders",
    detail:
      "React envia cliente y productos al servicio de pedidos mediante HTTP. El frontend no se conecta directamente a Kafka.",
    code: '{ "customer": "Laura", "items": [{ "productId": "coffee", "quantity": 2 }] }',
  },
  {
    title: "Pedidos guarda antes de publicar",
    label: "Transaccion local",
    icon: ShoppingBag,
    node: "orders",
    tag: "PostgreSQL / orders",
    detail:
      "Express valida el pedido, calcula el total desde su catalogo y guarda el pedido junto con su evento en el outbox, en una sola transaccion. Responde 202 Accepted: recibido, todavia no facturado.",
    code: "BEGIN → INSERT orders.orders + INSERT orders.outbox → COMMIT",
  },
  {
    title: "El productor publica el evento",
    label: "Publicacion outbox",
    icon: Radio,
    node: "orders",
    tag: "orders.created",
    detail:
      "Cada segundo, el publicador del servicio de pedidos busca eventos pendientes y los envia a Kafka. Solo marca el outbox como publicado cuando el broker confirma la recepcion.",
    code: 'topic: "orders.created"  |  key: orderId  |  value: evento JSON',
  },
  {
    title: "Kafka conserva el evento en una particion",
    label: "Topic y particiones",
    icon: Layers3,
    node: "kafka",
    tag: "3 particiones / 1 broker",
    detail:
      "El productor elige el topic orders.created y el particionador de KafkaJS usa orderId para elegir una de sus tres particiones. Cada particion es un registro ordenado; el evento recibe un offset dentro de ella.",
    code: "orders.created → P0, P1 o P2 → offset dentro de esa particion",
  },
  {
    title: "El grupo de facturacion consume",
    label: "Consumer group",
    icon: Users,
    node: "billing",
    tag: "billing-v1",
    detail:
      "El consumidor de billing pertenece al grupo billing-v1 y esta suscrito a orders.created. En esta demo hay una instancia que recibe las tres particiones; consume y procesa cada mensaje antes de avanzar su offset.",
    code: 'groupId: "billing-v1"  |  subscribe: "orders.created"',
  },
  {
    title: "Billing crea una sola factura",
    label: "Factura idempotente",
    icon: FileCheck2,
    node: "billing",
    tag: "PostgreSQL / billing",
    detail:
      "Billing consume orders.created, no invoices.created. Guarda la factura y su evento de confirmacion en otra transaccion local. UNIQUE(order_id) evita emitir otra factura si el pedido vuelve a llegar.",
    code: "BEGIN → INSERT billing.invoices + INSERT billing.outbox → COMMIT",
  },
  {
    title: "La confirmacion vuelve por Kafka",
    label: "Evento de retorno",
    icon: GitBranch,
    node: "kafka",
    tag: "invoices.created",
    detail:
      "El publicador outbox de billing emite invoices.created en un segundo topic, tambien con tres particiones. El grupo orders-v1, dentro del servicio de pedidos, consume esta confirmacion.",
    code: 'billing → "invoices.created" → orders-v1 → orders',
  },
  {
    title: "El pedido queda facturado",
    label: "Consistencia eventual",
    icon: CheckCheck,
    node: "orders",
    tag: "pending → invoiced",
    detail:
      "Pedidos actualiza su propio registro con el identificador de factura. React consulta las APIs de pedidos y facturas cada tres segundos para mostrar el resultado. No hay una llamada HTTP entre los dos backends.",
    code: "orders.orders.status = 'invoiced' → GET /api/orders → React",
  },
];

export default function Architecture() {
  const [step, setStep] = useState(0);
  const [playbackRequested, setPlaybackRequested] = useState(false);
  const [topic, setTopic] = useState("orders.created");
  const [consumerCount, setConsumerCount] = useState(1);
  const playing = playbackRequested && step < steps.length - 1;

  useEffect(() => {
    if (!playing) return;
    const timer = setInterval(() => {
      setStep((current) => {
        if (current === steps.length - 1) return current;
        return current + 1;
      });
    }, 2400);
    return () => clearInterval(timer);
  }, [playing]);

  const current = steps[step];
  const consumerGroup = topic === "orders.created" ? "billing-v1" : "orders-v1";
  const consumerService = topic === "orders.created" ? "billing" : "orders";
  function chooseStep(index) {
    setStep(index);
    setPlaybackRequested(false);
  }

  return (
    <div className="architecture-view">
      <section className="architecture-map" aria-labelledby="map-title">
        <header className="arch-section-heading">
          <div>
            <p className="arch-kicker">01 / MAPA DEL SISTEMA</p>
            <h2 id="map-title">Dos servicios. Un flujo de eventos.</h2>
          </div>
          <span className="arch-illustration-label">
            <span aria-hidden="true" />{" "}
            Recorrido ilustrativo
          </span>
        </header>
        <div className="arch-map-canvas">
          <div
            className="arch-map-route"
            aria-label="Frontend a pedidos, Kafka y facturacion"
          >
            <SystemNode
              icon={Monitor}
              name="Frontend"
              technology="React + Vite"
              active={current.node === "frontend"}
              step="01"
              detail="Crea pedidos y consulta estados"
            />
            <Connection label="HTTP" detail="POST /api/orders" />
            <SystemNode
              icon={ShoppingBag}
              name="Pedidos"
              technology="Express :3001"
              active={current.node === "orders"}
              step="02"
              detail="Productor + consumidor"
            />
            <Connection label="PRODUCE" detail="orders.created" />
            <SystemNode
              icon={Layers3}
              name="Kafka"
              technology="1 broker / KRaft"
              active={current.node === "kafka"}
              step="03"
              detail="2 topics / 3 particiones cada uno"
              kafka
            />
            <Connection label="CONSUME" detail="billing-v1" />
            <SystemNode
              icon={FileText}
              name="Facturacion"
              technology="Express :3002"
              active={current.node === "billing"}
              step="04"
              detail="Consumidor + productor"
            />
          </div>
          <div className={`arch-return-route ${step >= 6 ? "is-active" : ""}`}>
            <ArrowLeft size={17} />
            <span>
              <strong>orders-v1</strong> consume la confirmacion
            </span>
            <span className="arch-return-line" />
            <code>invoices.created</code>
            <span>Billing publica</span>
            <GitBranch size={16} />
          </div>
          <div className="arch-data-route">
            <Database size={17} />
            <strong>PostgreSQL</strong>
            <span>Una instancia, dos esquemas propios</span>
            <code>orders.orders + orders.outbox</code>
            <code>billing.invoices + billing.outbox</code>
          </div>
        </div>
        <div className="arch-player">
          <div className="arch-player-buttons">
            <button
              type="button"
              className="arch-play-button"
              title={playing ? "Pausar recorrido" : "Reproducir recorrido"}
              aria-label={playing ? "Pausar recorrido" : "Reproducir recorrido"}
              onClick={() => {
                if (!playing && step === steps.length - 1) {
                  setStep(0);
                }
                setPlaybackRequested(!playing);
              }}
            >
              {playing ? <Pause size={17} /> : <Play size={17} />}
            </button>
            <button
              type="button"
              className="icon-button"
              title="Reiniciar recorrido"
              aria-label="Reiniciar recorrido"
              onClick={() => chooseStep(0)}
            >
              <RotateCcw size={16} />
            </button>
          </div>
          <div
            className="arch-progress"
            aria-label={`Paso ${step + 1} de ${steps.length}`}
          >
            {steps.map((item, index) => (
              <button
                type="button"
                key={item.title}
                title={item.label}
                aria-label={`Paso ${index + 1}: ${item.label}`}
                aria-pressed={step === index}
                className={index <= step ? "visited" : ""}
                onClick={() => chooseStep(index)}
              >
                <span />
              </button>
            ))}
          </div>
          <span className="arch-step-count">
            {String(step + 1).padStart(2, "0")} / 08
          </span>
          <button
            type="button"
            className="icon-button"
            aria-label="Paso anterior"
            title="Paso anterior"
            disabled={step === 0}
            onClick={() => chooseStep(step - 1)}
          >
            <ArrowLeft size={16} />
          </button>
          <button
            type="button"
            className="icon-button"
            aria-label="Paso siguiente"
            title="Paso siguiente"
            disabled={step === steps.length - 1}
            onClick={() => chooseStep(step + 1)}
          >
            <ArrowRight size={16} />
          </button>
        </div>
        <div className="arch-step-detail" aria-live="polite" aria-atomic="true">
          <div className="arch-step-number">
            {String(step + 1).padStart(2, "0")}
          </div>
          <div>
            <div className="arch-detail-heading">
              <h3>{current.title}</h3>
              <span>{current.tag}</span>
            </div>
            <p>{current.detail}</p>
            <code className="arch-code-line">{current.code}</code>
          </div>
        </div>
      </section>

      <section
        className="arch-partition-section"
        aria-labelledby="partition-title"
      >
        <header className="arch-section-heading">
          <div>
            <p className="arch-kicker">02 / DENTRO DE KAFKA</p>
            <h2 id="partition-title">Un topic no es una sola cola.</h2>
          </div>
          <a
            href="http://localhost:18081"
            target="_blank"
            rel="noreferrer"
            className="arch-external-link"
          >
            Ver Kafka real <ArrowUpRight size={15} />
          </a>
        </header>
        <p className="arch-section-intro">
          Cada topic de este proyecto se crea con <strong>3 particiones</strong>{" "}
          y factor de replicacion <strong>1</strong>. Las particiones permiten
          repartir el trabajo; no son copias del mismo mensaje.
        </p>
        <fieldset
          className="arch-topic-tabs"
          aria-label="Topic ilustrado"
        >
          {["orders.created", "invoices.created"].map((name) => (
            <button
              type="button"
              key={name}
              aria-pressed={topic === name}
              className={topic === name ? "selected" : ""}
              onClick={() => setTopic(name)}
            >
              <Radio size={14} />
              {name}
            </button>
          ))}
        </fieldset>
        <div className="arch-partition-layout">
          <div className="arch-partition-log">
            <div className="arch-log-heading">
              <span>
                <Layers3 size={15} />
                <strong>{topic}</strong>
              </span>
              <small>MENSAJES Y OFFSETS ILUSTRATIVOS</small>
            </div>
            {[0, 1, 2].map((partition) => (
              <div className="arch-partition-row" key={partition}>
                <span className="arch-partition-name">P{partition}</span>
                <div className="arch-log-cells">
                  {[0, 1, 2, 3].map((offset) => (
                    <div
                      key={offset}
                      className={`arch-log-cell ${partition === 1 && offset === 3 ? "example-event" : ""}`}
                    >
                      <span>
                        {partition === 1 && offset === 3 ? "PED-042" : "evento"}
                      </span>
                      <small>offset {offset}</small>
                    </div>
                  ))}
                </div>
                <ArrowRight size={16} />
                <span className="arch-assignment">
                  C{(partition % consumerCount) + 1}
                </span>
              </div>
            ))}
            <div className="arch-log-footer">
              <span>
                <span className="arch-example-dot" aria-hidden="true" />{" "}
                key: orderId = PED-042
              </span>
              <span>
                Orden dentro de cada particion <ArrowRight size={13} />
              </span>
            </div>
          </div>
          <div className="arch-group">
            <div className="arch-group-heading">
              <Users size={20} />
              <div>
                <small>CONSUMER GROUP</small>
                <h3>{consumerGroup}</h3>
              </div>
            </div>
            <p>
              En el despliegue actual:{" "}
              <strong>1 consumidor de {consumerService}</strong> lee P0, P1 y
              P2.
            </p>
            <p className="arch-consumer-label">
              Ejemplo de reparto de particiones
            </p>
            <fieldset
              className="arch-consumer-options"
              aria-label="Cantidad ilustrativa de consumidores"
            >
              {[1, 2, 3, 4].map((count) => (
                <button
                  type="button"
                  key={count}
                  aria-pressed={consumerCount === count}
                  onClick={() => setConsumerCount(count)}
                >
                  {count}
                </button>
              ))}
            </fieldset>
            <div className="arch-consumer-list">
              {Array.from({ length: consumerCount }, (_, index) => {
                const assigned = [0, 1, 2].filter(
                  (partition) => partition % consumerCount === index,
                );
                return (
                  <div
                    className={`arch-consumer ${assigned.length ? "" : "idle"}`}
                    key={index}
                  >
                    <Server size={15} />
                    <strong>C{index + 1}</strong>
                    <span>
                      {assigned.length
                        ? assigned
                            .map((partition) => `P${partition}`)
                            .join(" + ")
                        : "Sin particion asignada"}
                    </span>
                  </div>
                );
              })}
            </div>
            <p className="arch-group-note">
              Asignacion posible, no lectura del cluster. Cambiar este ejemplo
              no crea replicas ni modifica Kafka.
            </p>
          </div>
        </div>
        <div className="arch-concepts">
          <Concept icon={GitBranch} title="La clave mantiene el recorrido">
            KafkaJS elige una particion usando <code>orderId</code>. Con el
            mismo numero de particiones, la misma clave va a la misma particion
            dentro de ese topic. P1 es solo el ejemplo visual.
          </Concept>
          <Concept icon={Users} title="Una particion, un consumidor del grupo">
            Kafka asigna cada particion a un solo miembro del grupo a la vez.
            Con tres particiones, como maximo tres miembros pueden tener trabajo
            asignado; un cuarto queda sin particion.
          </Concept>
          <Concept
            icon={CheckCheck}
            title="El offset es una posicion, no un borrado"
          >
            Cada grupo guarda su avance por particion. Leer un evento no lo
            elimina: Kafka lo conserva segun su retencion y otros grupos
            mantienen offsets independientes.
          </Concept>
        </div>
        <p className="arch-technical-note">
          <ShieldCheck size={16} />
          <span>
            El orden se garantiza por particion, no entre particiones ni entre
            topics. El publicador outbox actual admite una replica por servicio;
            el ejemplo de consumidores no habilita escalado seguro del backend.
          </span>
        </p>
      </section>

      <section className="arch-support-section" aria-labelledby="support-title">
        <header className="arch-section-heading">
          <div>
            <p className="arch-kicker">03 / LO QUE SOSTIENE EL FLUJO</p>
            <h2 id="support-title">
              Persistencia, recuperacion y observabilidad.
            </h2>
          </div>
        </header>
        <div className="arch-support-grid">
          <Concept icon={Database} title="Dos propietarios de datos">
            Pedidos escribe en el esquema <code>orders</code>; facturacion, en{" "}
            <code>billing</code>. Comparten una instancia PostgreSQL por
            simplicidad, pero no consultan las tablas del otro servicio.
          </Concept>
          <Concept
            icon={ShieldCheck}
            title="Al menos una vez, sin doble factura"
          >
            Outbox evita perder el evento entre guardar y publicar. Puede haber
            reentregas; <code>UNIQUE(order_id)</code> hace idempotente la
            factura. No es entrega exactly-once.
          </Concept>
          <Concept icon={RotateCcw} title="Si billing se detiene">
            Pedidos puede seguir publicando mientras Kafka este disponible. El
            grupo conserva su avance y procesa lo pendiente al volver, siempre
            que los mensajes sigan retenidos.
          </Concept>
        </div>
        <div className="arch-observability">
          <Activity size={19} />
          <div>
            <h3>Una ventana a cada capa</h3>
            <p>
              Prometheus consulta <code>/metrics</code> de ambos backends;
              Grafana grafica esos datos. Kafbat inspecciona topics,
              particiones, mensajes, grupos y lag. No intervienen en el flujo de
              negocio.
            </p>
          </div>
          <div className="arch-observability-links">
            <a href="http://localhost:9090" target="_blank" rel="noreferrer">
              Prometheus <ArrowUpRight size={13} />
            </a>
            <a
              href="http://localhost:3000/d/pedido-flow"
              target="_blank"
              rel="noreferrer"
            >
              Grafana <ArrowUpRight size={13} />
            </a>
            <a href="http://localhost:18081" target="_blank" rel="noreferrer">
              Kafbat <ArrowUpRight size={13} />
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

function SystemNode({
  icon: Icon,
  name,
  technology,
  active,
  step,
  detail,
  kafka,
}) {
  return (
    <div
      className={`arch-system-node ${active ? "active" : ""} ${kafka ? "kafka" : ""}`}
    >
      <div className="arch-node-heading">
        <span className="arch-node-icon">
          <Icon size={25} strokeWidth={1.6} />
        </span>
        <span className="arch-node-index">{step}</span>
      </div>
      <h3>{name}</h3>
      <code>{technology}</code>
      <p>{detail}</p>
    </div>
  );
}

function Connection({ label, detail }) {
  return (
    <div className="arch-connection">
      <small>{label}</small>
      <div>
        <span />
        <ArrowRight size={17} />
      </div>
      <code>{detail}</code>
    </div>
  );
}

function Concept({ icon: Icon, title, children }) {
  return (
    <article className="arch-concept">
      <Icon size={20} strokeWidth={1.6} />
      <h3>{title}</h3>
      <p>{children}</p>
    </article>
  );
}
