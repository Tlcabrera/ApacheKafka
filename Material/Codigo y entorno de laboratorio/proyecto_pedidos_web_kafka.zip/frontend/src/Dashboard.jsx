import { startTransition, useEffect, useRef, useState } from "react";
import {
  Activity,
  ArrowDownToLine,
  ArrowRight,
  ArrowUpRight,
  Box,
  Check,
  ChevronRight,
  CircleCheck,
  Clock3,
  Database,
  FileText,
  GitBranch,
  Layers3,
  LoaderCircle,
  Minus,
  Package,
  Plus,
  Radio,
  RefreshCw,
  Search,
  ShoppingBag,
  Workflow,
  X,
  Zap,
} from "lucide-react";
import "./dashboard.css";
import Architecture from "./Architecture.jsx";

const money = (value) =>
  new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
    maximumFractionDigits: 2,
  }).format(Number(value) / 100);
const time = (value) =>
  new Intl.DateTimeFormat("es-CO", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(new Date(value));
const shortId = (value) => value.slice(0, 8).toUpperCase();
const invoiceNumber = (value) => `FAC-${String(value).padStart(5, "0")}`;

async function request(path, options = {}) {
  const response = await fetch(path, options);
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || "No se pudo conectar con el servicio.");
  }
  return response.json();
}

function Status({ done }) {
  return (
    <span className={`status ${done ? "done" : "pending"}`}>
      {done ? <CircleCheck size={13} /> : <Clock3 size={13} />}
      {done ? "Facturado" : "Pendiente"}
    </span>
  );
}

async function submitOrder(order) {
  return request("/api/orders", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(order),
  });
}

function useDashboardData(tick) {
  const [data, setData] = useState({
    orders: [],
    invoices: [],
    products: [],
    health: {},
  });
  const [loading, setLoading] = useState(true);
  const [errors, setErrors] = useState([]);
  const [updated, setUpdated] = useState(null);

  useEffect(() => {
    const controller = new AbortController();
    let active = false;
    async function refresh() {
      if (active) return;
      active = true;
      const endpoints = [
        "/api/orders",
        "/api/invoices",
        "/api/products",
        "/api/health/orders",
        "/api/health/billing",
      ];
      const results = await Promise.allSettled(
        endpoints.map((path) => request(path, { signal: controller.signal })),
      );
      active = false;
      if (controller.signal.aborted) return;
      startTransition(() => {
        setData((previous) => ({
          orders:
            results[0].status === "fulfilled"
              ? results[0].value
              : previous.orders,
          invoices:
            results[1].status === "fulfilled"
              ? results[1].value
              : previous.invoices,
          products:
            results[2].status === "fulfilled"
              ? results[2].value
              : previous.products,
          health: {
            orders: results[3].status === "fulfilled",
            billing: results[4].status === "fulfilled",
          },
        }));
        setErrors(
          [
            results[0].status === "rejected" && "Pedidos no disponible",
            results[1].status === "rejected" && "Facturacion no disponible",
          ].filter(Boolean),
        );
        if (
          results[0].status === "fulfilled" ||
          results[1].status === "fulfilled"
        )
          setUpdated(new Date());
        setLoading(false);
      });
    }
    void refresh();
    const timer = setInterval(() => {
      void refresh();
    }, 3000);
    return () => {
      controller.abort();
      clearInterval(timer);
    };
  }, [tick]);
  return { data, loading, errors, updated };
}

export default function Dashboard() {
  const [today] = useState(() => new Date());
  const [view, setView] = useState("orders");
  const [tick, setTick] = useState(0);
  const { data, loading, errors, updated } = useDashboardData(tick);
  const [search, setSearch] = useState("");
  const [modal, setModal] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(""), 6000);
    return () => clearTimeout(timer);
  }, [notice]);

  const invoicesByOrder = new Map(
    data.invoices.map((invoice) => [invoice.order_id, invoice]),
  );
  const selected =
    data.orders.find((order) => order.id === selectedId) || data.orders[0];
  const completed = data.orders.filter(
    (order) => order.status === "invoiced",
  ).length;
  const pending = data.orders.length - completed;
  const total = data.invoices.reduce(
    (sum, invoice) => sum + Number(invoice.total_cents),
    0,
  );
  const query = search.trim().toLowerCase();
  const orders = data.orders.filter((order) =>
    `${order.id} ${order.customer}`.toLowerCase().includes(query),
  );
  const invoices = data.invoices.filter((invoice) =>
    `${invoiceNumber(invoice.number)} ${invoice.customer} ${invoice.order_id}`
      .toLowerCase()
      .includes(query),
  );

  async function generateBatch() {
    setBusy(true);
    try {
      const customers = [
        "Maria Garcia",
        "Daniel Rojas",
        "Valentina Ruiz",
        "Andres Torres",
        "Camila Lopez",
      ];
      const results = await Promise.allSettled(
        customers.map((customer, index) =>
          submitOrder({
            customer,
            items: [
              {
                productId: data.products[index % data.products.length].id,
                quantity: (index % 3) + 1,
              },
            ],
          }),
        ),
      );
      const created = results.filter(
        (result) => result.status === "fulfilled",
      ).length;
      setNotice(`${created} de 5 pedidos enviados a procesamiento.`);
    } catch (error) {
      setNotice(error.message);
    } finally {
      setBusy(false);
      setTick((value) => value + 1);
    }
  }

  const nav = (id, label, Icon, count) => (
    <button
      aria-label={label}
      title={label}
      className={`nav-item ${view === id ? "active" : ""}`}
      onClick={() => {
        setView(id);
        setSearch("");
      }}
    >
      <Icon size={18} />
      <span>{label}</span>
      {count !== undefined && <span className="nav-count">{count}</span>}
    </button>
  );
  const titles = {
    orders: "Pedidos",
    invoices: "Facturas",
    activity: "Actividad de eventos",
    architecture: "Arquitectura",
  };
  const captions = {
    orders: "Tu operacion, en tiempo real.",
    invoices: "Comprobantes emitidos por el servicio de facturacion.",
    activity: "El recorrido de cada pedido.",
    architecture: "Del pedido a la factura, evento a evento.",
  };
  const connected = data.health.orders && data.health.billing;
  let connectionLabel = connected ? "Servicios conectados" : "Conexion parcial";
  if (loading) connectionLabel = "Conectando";

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <a className="brand" href="/" aria-label="Pedido Flow, inicio">
          <span className="brand-mark">
            <Workflow size={23} />
          </span>
          <span>
            pedido<span className="brand-light">flow</span>
            <small>EVENT-DRIVEN COMMERCE</small>
          </span>
        </a>
        <div className="workspace-label">
          <span className="workspace-avatar">P</span>
          <div>
            Workspace local<small>Entorno de demostracion</small>
          </div>
          <span className="local-dot" />
        </div>
        <p className="nav-label">OPERACION</p>
        <nav aria-label="Principal">
          {nav("orders", "Pedidos", ShoppingBag, data.orders.length)}
          {nav("invoices", "Facturas", FileText, data.invoices.length)}
          {nav("activity", "Actividad", Activity)}
          {nav("architecture", "Arquitectura", Workflow)}
        </nav>
        <p className="nav-label tools-label">OBSERVABILIDAD</p>
        <nav aria-label="Observabilidad">
          <a
            className="nav-item"
            href="http://localhost:18081"
            aria-label="Kafbat UI"
            title="Kafbat UI"
            target="_blank"
            rel="noreferrer"
          >
            <Layers3 size={18} />
            <span>Kafbat UI</span>
            <ArrowUpRight size={14} />
          </a>
          <a
            className="nav-item"
            href="http://localhost:3000/d/pedido-flow"
            aria-label="Grafana"
            title="Grafana"
            target="_blank"
            rel="noreferrer"
          >
            <Activity size={18} />
            <span>Grafana</span>
            <ArrowUpRight size={14} />
          </a>
          <a
            className="nav-item"
            href="http://localhost:9090"
            aria-label="Prometheus"
            title="Prometheus"
            target="_blank"
            rel="noreferrer"
          >
            <Radio size={18} />
            <span>Prometheus</span>
            <ArrowUpRight size={14} />
          </a>
        </nav>
        <div className="sidebar-bottom">
          <div>
            <span className="local-dot" />
            LOCAL DEVELOPMENT
          </div>
          <span>Kafka / PostgreSQL / Express</span>
          <small>v1.0.0</small>
        </div>
      </aside>

      <div className="main-shell">
        <header className="topbar">
          <div className="breadcrumb">
            Workspace <ChevronRight size={13} />
            <strong>{titles[view]}</strong>
          </div>
          <div className="environment">
            <span
              className={
                data.health.orders && data.health.billing
                  ? "local-dot"
                  : "local-dot warning"
              }
            />
            {connectionLabel}
            <span className="env-tag">LOCAL</span>
          </div>
        </header>
        <main>
          <div
            className={`page-heading ${view === "architecture" ? "architecture-page-heading" : ""}`}
          >
            <div>
              <p className="eyebrow">
                OPERACIONES /{" "}
                {new Intl.DateTimeFormat("es-CO", {
                  day: "2-digit",
                  month: "long",
                  year: "numeric",
                })
                  .format(today)
                  .toUpperCase()}
              </p>
              <h1>
                {titles[view]}
                <span className="heading-dot">.</span>
              </h1>
              <p className="page-caption">{captions[view]}</p>
            </div>
            <div className="heading-actions">
              <button
                className="button secondary"
                onClick={generateBatch}
                disabled={busy || !data.products.length}
              >
                {busy ? (
                  <LoaderCircle className="spin" size={16} />
                ) : (
                  <Zap size={16} />
                )}
                Generar 5 pedidos
              </button>
              <button
                className="button primary"
                onClick={() => setModal({ type: "order" })}
                disabled={!data.products.length}
              >
                <Plus size={17} />
                Nuevo pedido
              </button>
            </div>
          </div>

          {errors.length > 0 && (
            <div className="error-banner" role="alert">
              <Radio size={16} />
              {errors.join(" · ")}. Los datos visibles pueden estar
              desactualizados.
              <button
                title="Reintentar conexion"
                aria-label="Reintentar conexion"
                onClick={() => setTick((value) => value + 1)}
              >
                <RefreshCw size={15} />
              </button>
            </div>
          )}

          {view === "architecture" ? (
            <Architecture />
          ) : (
            <>
              <section
                className="metrics"
                aria-label="Resumen de los ultimos 100 registros"
              >
                <Metric
                  label="PEDIDOS RECIBIDOS"
                  value={data.orders.length}
                  icon={ShoppingBag}
                  note="Ultimos 100 pedidos"
                />
                <Metric
                  label="FACTURAS EMITIDAS"
                  value={data.invoices.length}
                  icon={FileText}
                  note={`${completed} pedidos confirmados`}
                  green
                />
                <Metric
                  label="EN PROCESAMIENTO"
                  value={pending}
                  icon={Clock3}
                  note={
                    pending
                      ? "Pendientes de confirmacion"
                      : "Sin pedidos pendientes"
                  }
                />
                <Metric
                  label="TOTAL FACTURADO"
                  value={money(total)}
                  icon={ArrowUpRight}
                  note="COP · Ultimas 100 facturas"
                />
              </section>

              <section className="flow-strip" aria-label="Estado de servicios">
                <div className="flow-label">
                  <GitBranch size={16} />
                  <span>EVENT PIPELINE</span>
                </div>
                <div className="flow-node">
                  <span
                    className={`service-dot ${data.health.orders ? "up" : ""}`}
                  />
                  <strong>Pedidos</strong>
                  <small>Express :3001</small>
                </div>
                <div className="flow-connector">
                  <span>orders.created</span>
                  <ArrowRight size={17} />
                </div>
                <div className="kafka-node">
                  <Layers3 size={19} />
                  <strong>Kafka</strong>
                </div>
                <div className="flow-connector">
                  <span>consumer group</span>
                  <ArrowRight size={17} />
                </div>
                <div className="flow-node">
                  <span
                    className={`service-dot ${data.health.billing ? "up" : ""}`}
                  />
                  <strong>Facturacion</strong>
                  <small>Express :3002</small>
                </div>
              </section>

              <div className="content-grid">
                <section className="records-section">
                  <div className="section-heading">
                    <div className="tabs" role="tablist" aria-label="Registros">
                      <button
                        role="tab"
                        aria-selected={view === "orders"}
                        className={view === "orders" ? "selected" : ""}
                        onClick={() => {
                          setView("orders");
                          setSearch("");
                        }}
                      >
                        Pedidos <span>{data.orders.length}</span>
                      </button>
                      <button
                        role="tab"
                        aria-selected={view === "invoices"}
                        className={view === "invoices" ? "selected" : ""}
                        onClick={() => {
                          setView("invoices");
                          setSearch("");
                        }}
                      >
                        Facturas <span>{data.invoices.length}</span>
                      </button>
                      <button
                        role="tab"
                        aria-selected={view === "activity"}
                        className={view === "activity" ? "selected" : ""}
                        onClick={() => setView("activity")}
                      >
                        Eventos
                      </button>
                    </div>
                    <button
                      className="icon-button"
                      title="Actualizar registros"
                      aria-label="Actualizar registros"
                      onClick={() => setTick((value) => value + 1)}
                    >
                      <RefreshCw size={16} />
                    </button>
                  </div>
                  <div className="table-toolbar">
                    <label className="search-field">
                      <Search size={16} />
                      <input
                        placeholder={
                          view === "invoices"
                            ? "Buscar factura o cliente..."
                            : "Buscar pedido o cliente..."
                        }
                        value={search}
                        onChange={(event) => setSearch(event.target.value)}
                        aria-label="Buscar registros"
                      />
                    </label>
                    <span className="record-count">
                      {view === "invoices" ? invoices.length : orders.length}{" "}
                      registros
                    </span>
                  </div>

                  <Records
                    loading={loading}
                    view={view}
                    orders={orders}
                    invoices={invoices}
                    selectedId={selected?.id}
                    onSelect={setSelectedId}
                    onInvoice={(invoice) =>
                      setModal({ type: "invoice", invoice })
                    }
                    query={query}
                    onNew={() => setModal({ type: "order" })}
                    canCreate={Boolean(data.products.length)}
                  />
                  <div className="table-footer">
                    <span>
                      <span className="local-dot" />
                      {updated
                        ? `Actualizado ${time(updated)}`
                        : "Esperando conexion"}
                    </span>
                    <span>Ultimos 100 registros</span>
                  </div>
                </section>

                <aside className="trace-panel">
                  <div className="trace-title">
                    <span>TRAZABILIDAD</span>
                    <GitBranch size={16} />
                  </div>
                  {selected ? (
                    <>
                      <div className="trace-order">
                        <span className="trace-package">
                          <Package size={22} />
                        </span>
                        <h2>PED-{shortId(selected.id)}</h2>
                        <p>{selected.customer}</p>
                        <Status done={selected.status === "invoiced"} />
                      </div>
                      <div className="timeline">
                        <TimelineStep
                          done
                          title="Pedido recibido"
                          detail={time(selected.created_at)}
                        />
                        <TimelineStep
                          done
                          title="Evento registrado"
                          detail="orders.created · outbox"
                        />
                        <TimelineStep
                          done={Boolean(selected.invoice_id)}
                          title="Factura emitida"
                          detail={
                            selected.invoice_id
                              ? invoiceNumber(
                                  invoicesByOrder.get(selected.id)?.number ||
                                    "...",
                                )
                              : "Esperando a facturacion"
                          }
                        />
                        <TimelineStep
                          done={Boolean(selected.invoiced_at)}
                          title="Pedido confirmado"
                          detail={
                            selected.invoiced_at
                              ? time(selected.invoiced_at)
                              : "invoices.created"
                          }
                        />
                      </div>
                      <dl className="trace-total">
                        <dt>Total del pedido</dt>
                        <dd>{money(selected.total_cents)}</dd>
                      </dl>
                      <button
                        className="trace-link"
                        onClick={() =>
                          window.open(
                            "http://localhost:18081",
                            "_blank",
                            "noopener,noreferrer",
                          )
                        }
                      >
                        Abrir en Kafbat <ArrowUpRight size={15} />
                      </button>
                    </>
                  ) : (
                    <div className="trace-empty">
                      <Box size={35} strokeWidth={1.3} />
                      <h3>Sin pedido seleccionado</h3>
                    </div>
                  )}
                  <div className="storage-note">
                    <Database size={15} />
                    <span>
                      PostgreSQL <strong>Persistencia local</strong>
                    </span>
                  </div>
                </aside>
              </div>
            </>
          )}
          <footer className="page-footer">
            <span>
              pedido<span>flow</span>
            </span>
            <p>Un pedido. Un evento. Una factura.</p>
            <span className="footer-right">EDA / DEMO LOCAL</span>
          </footer>
        </main>
      </div>

      {notice && (
        <output className="toast">
          {notice}
          <button
            onClick={() => setNotice("")}
            aria-label="Cerrar notificacion"
          >
            <X size={16} />
          </button>
        </output>
      )}
      {modal && (
        <Modal onClose={() => setModal(null)}>
          {modal.type === "order" ? (
            <OrderForm
              products={data.products}
              onCancel={() => setModal(null)}
              onSubmit={async (order) => {
                const result = await submitOrder(order);
                setModal(null);
                setSelectedId(result.id);
                setView("orders");
                setTick((value) => value + 1);
                setNotice(`Pedido ${shortId(result.id)} recibido.`);
              }}
            />
          ) : (
            <Invoice invoice={modal.invoice} />
          )}
        </Modal>
      )}
    </div>
  );
}

function Modal({ children, onClose }) {
  const reference = useRef(null);
  useEffect(() => {
    const dialog = reference.current;
    dialog.showModal();
    return () => dialog.close();
  }, []);
  return (
    <dialog
      ref={reference}
      className="modal"
      aria-labelledby="modal-title"
      onCancel={onClose}
    >
      <button
        type="button"
        className="modal-close icon-button"
        onClick={onClose}
        title="Cerrar"
        aria-label="Cerrar"
      >
        <X size={20} />
      </button>
      {children}
    </dialog>
  );
}

function Records({
  loading,
  view,
  orders,
  invoices,
  selectedId,
  onSelect,
  onInvoice,
  query,
  onNew,
  canCreate,
}) {
  if (loading)
    return (
      <div className="empty-state">
        <LoaderCircle className="spin" size={28} />
        <h3>Cargando registros</h3>
      </div>
    );
  if (view === "activity")
    return <EventList orders={orders} onSelect={onSelect} />;
  if (view === "invoices")
    return (
      <div className="table-scroll">
        <table>
          <thead>
            <tr>
              <th>FACTURA / CLIENTE</th>
              <th>PEDIDO</th>
              <th>IMPORTE</th>
              <th>EMISION</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {invoices.map((invoice) => (
              <tr key={invoice.id}>
                <td>
                  <button
                    className="row-button"
                    onClick={() => onInvoice(invoice)}
                  >
                    {invoiceNumber(invoice.number)}
                  </button>
                  <small>{invoice.customer}</small>
                </td>
                <td className="mono">{shortId(invoice.order_id)}</td>
                <td className="amount">{money(invoice.total_cents)}</td>
                <td>{time(invoice.created_at)}</td>
                <td>
                  <ChevronRight size={15} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!invoices.length && (
          <Empty
            icon={FileText}
            title={query ? "Sin coincidencias" : "Aun no hay facturas"}
          />
        )}
      </div>
    );
  return (
    <div className="table-scroll">
      <table>
        <thead>
          <tr>
            <th>PEDIDO / CLIENTE</th>
            <th>ESTADO</th>
            <th>IMPORTE</th>
            <th>RECIBIDO</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => (
            <tr
              key={order.id}
              className={selectedId === order.id ? "selected-row" : ""}
            >
              <td>
                <button
                  className="row-button"
                  onClick={() => onSelect(order.id)}
                >
                  PED-{shortId(order.id)}
                </button>
                <small>{order.customer}</small>
              </td>
              <td>
                <Status done={order.status === "invoiced"} />
              </td>
              <td className="amount">{money(order.total_cents)}</td>
              <td className="time-cell">{time(order.created_at)}</td>
              <td>
                <ChevronRight size={15} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {!orders.length && (
        <Empty
          icon={ShoppingBag}
          title={query ? "Sin coincidencias" : "Tu primer pedido empieza aqui"}
          action={
            !query && (
              <button
                className="text-button"
                onClick={onNew}
                disabled={!canCreate}
              >
                Crear pedido <ArrowRight size={15} />
              </button>
            )
          }
        />
      )}
    </div>
  );
}

function EventList({ orders, onSelect }) {
  const events = orders
    .flatMap((order) => {
      const created = {
        id: `${order.id}-created`,
        topic: "orders.created",
        date: order.created_at,
        customer: order.customer,
        order,
      };
      if (!order.invoiced_at) return [created];
      return [
        created,
        {
          id: `${order.id}-invoice`,
          topic: "invoices.created",
          date: order.invoiced_at,
          customer: order.customer,
          order,
        },
      ];
    })
    .sort((first, second) => new Date(second.date) - new Date(first.date));
  return (
    <div className="event-list">
      {events.map((event) => (
        <button
          className="event-row"
          key={event.id}
          onClick={() => onSelect(event.order.id)}
        >
          <span className="event-icon">
            <Radio size={16} />
          </span>
          <span>
            <strong>{event.topic}</strong>
            <small>
              {event.customer} / {shortId(event.order.id)}
            </small>
          </span>
          <time>{time(event.date)}</time>
          <ChevronRight size={14} />
        </button>
      ))}
      {!events.length && <Empty icon={Radio} title="Sin eventos todavia" />}
    </div>
  );
}

function Metric({ label, value, icon: Icon, note, green }) {
  return (
    <div className={`metric ${green ? "green-metric" : ""}`}>
      <div className="metric-label">
        {label}
        <Icon size={17} />
      </div>
      <div className="metric-value">{value}</div>
      <div className="metric-note">
        {green && <span className="local-dot" />}
        {note}
      </div>
    </div>
  );
}

function Empty({ icon: Icon, title, action }) {
  return (
    <div className="empty-state">
      <span className="empty-icon">
        <Icon size={26} strokeWidth={1.5} />
      </span>
      <h3>{title}</h3>
      {action}
    </div>
  );
}

function TimelineStep({ done, title, detail }) {
  return (
    <div className={`timeline-step ${done ? "complete" : ""}`}>
      <span className="timeline-dot">
        {done ? <Check size={11} /> : <span />}
      </span>
      <div>
        <h3>{title}</h3>
        <p>{detail}</p>
      </div>
    </div>
  );
}

function OrderForm({ products, onSubmit, onCancel }) {
  const [customer, setCustomer] = useState("");
  const [quantities, setQuantities] = useState({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const total = products.reduce(
    (sum, product) => sum + product.priceCents * (quantities[product.id] || 0),
    0,
  );
  async function submit(event) {
    event.preventDefault();
    setSaving(true);
    setError("");
    try {
      await onSubmit({
        customer,
        items: products
          .filter((product) => quantities[product.id] > 0)
          .map((product) => ({
            productId: product.id,
            quantity: quantities[product.id],
          })),
      });
    } catch (error) {
      setError(error.message);
    } finally {
      setSaving(false);
    }
  }
  return (
    <form onSubmit={submit}>
      <p className="eyebrow">PEDIDOS / NUEVO</p>
      <h2 id="modal-title">
        Crear pedido<span className="heading-dot">.</span>
      </h2>
      <label className="customer-label">
        Nombre del cliente
        <input
          required
          minLength={2}
          maxLength={100}
          value={customer}
          onChange={(event) => setCustomer(event.target.value)}
          placeholder="Ej. Laura Martinez"
        />
      </label>
      <p className="form-section-title">PRODUCTOS</p>
      <div className="product-list">
        {products.map((product) => (
          <div className="product-row" key={product.id}>
            <img src={product.image} alt={product.name} />
            <div className="product-description">
              <small>{product.category}</small>
              <strong>{product.name}</strong>
              <span>{money(product.priceCents)}</span>
            </div>
            <div className="quantity-control">
              <button
                type="button"
                aria-label={`Quitar ${product.name}`}
                disabled={!quantities[product.id]}
                onClick={() =>
                  setQuantities({
                    ...quantities,
                    [product.id]: (quantities[product.id] || 0) - 1,
                  })
                }
              >
                <Minus size={13} />
              </button>
              <input
                type="number"
                min="0"
                max="50"
                step="1"
                aria-label={`Cantidad de ${product.name}`}
                value={quantities[product.id] || 0}
                onChange={(event) =>
                  setQuantities({
                    ...quantities,
                    [product.id]: Math.min(
                      50,
                      Math.max(0, Number(event.target.value)),
                    ),
                  })
                }
              />
              <button
                type="button"
                aria-label={`Agregar ${product.name}`}
                disabled={quantities[product.id] >= 50}
                onClick={() =>
                  setQuantities({
                    ...quantities,
                    [product.id]: (quantities[product.id] || 0) + 1,
                  })
                }
              >
                <Plus size={13} />
              </button>
            </div>
          </div>
        ))}
      </div>
      <div className="form-total">
        <span>
          Total <small>COP</small>
        </span>
        <strong>{money(total)}</strong>
      </div>
      {error && (
        <p className="form-error" role="alert">
          {error}
        </p>
      )}
      <div className="form-actions">
        <button
          type="button"
          className="button secondary"
          onClick={onCancel}
          disabled={saving}
        >
          Cancelar
        </button>
        <button
          type="submit"
          className="button primary"
          disabled={saving || !total || customer.trim().length < 2}
        >
          {saving ? (
            <LoaderCircle size={16} className="spin" />
          ) : (
            <ArrowRight size={16} />
          )}
          Crear pedido
        </button>
      </div>
    </form>
  );
}

function Invoice({ invoice }) {
  function download() {
    const url = URL.createObjectURL(
      new Blob([JSON.stringify(invoice, null, 2)], {
        type: "application/json",
      }),
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = `${invoiceNumber(invoice.number)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  }
  return (
    <div>
      <p className="eyebrow">FACTURACION / COMPROBANTE</p>
      <h2 id="modal-title">{invoiceNumber(invoice.number)}</h2>
      <p className="invoice-caption">Comprobante de demostracion</p>
      <dl className="invoice-meta">
        <dt>Cliente</dt>
        <dd>{invoice.customer}</dd>
        <dt>Pedido</dt>
        <dd className="mono">{shortId(invoice.order_id)}</dd>
        <dt>Emision</dt>
        <dd>{new Date(invoice.created_at).toLocaleString("es-CO")}</dd>
      </dl>
      <div className="invoice-lines">
        {invoice.items.map((item, index) => (
          <div key={`${item.productId}-${index}`}>
            <span>
              {item.name} <small>x{item.quantity}</small>
            </span>
            <strong>{money(item.quantity * item.priceCents)}</strong>
          </div>
        ))}
      </div>
      <div className="form-total">
        <span>
          Total <small>{invoice.currency}</small>
        </span>
        <strong>{money(invoice.total_cents)}</strong>
      </div>
      <button className="button primary download-button" onClick={download}>
        <ArrowDownToLine size={16} />
        Descargar JSON
      </button>
    </div>
  );
}
