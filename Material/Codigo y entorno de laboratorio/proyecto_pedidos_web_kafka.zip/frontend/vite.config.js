import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/api/invoices": "http://localhost:3002",
      "/api/health/orders": {
        target: "http://localhost:3001",
        rewrite: () => "/health",
      },
      "/api/health/billing": {
        target: "http://localhost:3002",
        rewrite: () => "/health",
      },
      "/api": "http://localhost:3001",
    },
  },
});
